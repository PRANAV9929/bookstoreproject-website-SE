package com.termproj.bookstore;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.sql.SQLOutput;

@SpringBootTest
class BookstoreApplicationTests {
	@Autowired
	private DataSource dataSource;

	@Test
	void contextLoads() {
	}

	/*
	HikariProxyConnection@255156436 wrapping com.mysql.cj.jdbc.ConnectionImpl@3ba3d4b6
	 */
	@Test
	void getConnection() throws SQLException {
		System.out.println(dataSource.getConnection());

	}
}
