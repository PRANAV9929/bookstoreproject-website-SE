package com.termproj.bookstore.service;

import com.termproj.bookstore.entity.User;
import com.termproj.bookstore.service.ex.ServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest
@RunWith(SpringRunner.class)
public class UserServiceTests {

    @Autowired
    private IUserService userService;
    @Test
    public void reg(){

        try {
            User user = new User();
            user.setUsername("Timi");
            user.setPassword("123123");

            userService.reg(user);
            System.out.println("OK");
        } catch (ServiceException e) {
            System.out.println(e.getClass().getSimpleName());
            System.out.println(e.getMessage());
        }
    }
    @Test
    public void login(){
       User user = userService.login("kw","112233");
        System.out.println(user);
    }

    @Test
    public void changePassword(){
        userService.changePassword(11,"kw","123","123");
    }

    @Test
    public void getByUid(){
        System.out.println( userService.getByUid(1));
    }

    @Test
    public void changeInfo(){
        User user = new User();
        user.setPhone("123123123");
        user.setEmail("email003");

        user.setActive(1);
        user.setCard("123456");
        user.setExpire("1206");
        user.setCvv("123");
        userService.changeInfo(3,"adm",user);
    }
}
