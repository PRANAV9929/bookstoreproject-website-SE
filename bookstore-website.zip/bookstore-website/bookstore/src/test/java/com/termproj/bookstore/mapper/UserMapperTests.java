package com.termproj.bookstore.mapper;


import com.termproj.bookstore.entity.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;

@SpringBootTest
@RunWith(SpringRunner.class)
public class UserMapperTests {

    @Autowired
    private UserMapper userMapper;
    @Test
    public void insert(){

        User user = new User();
        user.setUsername("Testaddress");
        user.setPassword("123123");

        Integer rows = userMapper.insert(user);
        System.out.println(rows);


    }
    @Test
    public void findByUsername(){
        User user = userMapper.findByUsername("Tim");
        System.out.println(user);
    }

    @Test
    public void updatePasswordByUid(){
        userMapper.updatePasswordByUid(20,"123","admin",new Date());
    }

    @Test
    public void findByUid(){
        System.out.println(userMapper.findByUid(20));

    }

    @Test
    public void updateInfoByUid(){
        User user = new User();
        user.setUid(1);
        user.setEmail("email050");
        user.setPhone("123456789");
        user.setActive(1);
        user.setCard("4444555566667777");
        user.setStreet1("jimmy street 404");
        user.setStates("Georgia");
        user.setSubscription(1);
        userMapper.updateInfoByUid(user);
    }

    //public void User getByUid(Integer uid){

    //}
}
