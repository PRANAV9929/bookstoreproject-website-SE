package com.termproj.bookstore.mapper;


import com.termproj.bookstore.entity.Cart;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;

@SpringBootTest
@RunWith(SpringRunner.class)
public class CartMapperTests {

    @Autowired
    private CartMapper cartMapper;
    @Test
    public void insert(){
        Cart cart = new Cart();
        cart.setBid(1);
        cart.setUid(11);
        cart.setNum(2);
        cart.setPrice(500);
        cartMapper.insert(cart);
    }

    @Test
    public void updateNumByCid(){
        cartMapper.updateNumByCid(9,4,"admin",new Date());
    }

    @Test
    public void findByUidAndPid(){
        Cart cart=cartMapper.findByUidAndBid(11,1);
        System.out.println(cart);

    }
    @Test
    public void findVOByUid(){
        System.out.println(cartMapper.findVOByUid(12));

    }
}
