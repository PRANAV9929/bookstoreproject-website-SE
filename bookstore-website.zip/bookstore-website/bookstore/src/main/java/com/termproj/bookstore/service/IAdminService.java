package com.termproj.bookstore.service;

import com.termproj.bookstore.entity.Admin;

public interface IAdminService {

    Admin login(String username, String password);

    Admin verifyLogin(String username, String password);
}
