package com.termproj.bookstore.service;

import com.termproj.bookstore.entity.Product;

import java.util.List;

public interface IProductService {
    List<Product> findList();

    Product findById(Integer id);
}
