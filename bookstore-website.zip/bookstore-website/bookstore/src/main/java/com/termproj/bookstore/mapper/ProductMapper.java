package com.termproj.bookstore.mapper;

import com.termproj.bookstore.entity.Product;

import java.util.List;

public interface ProductMapper {
    List<Product> findList();

    Product findById(Integer id);
}
