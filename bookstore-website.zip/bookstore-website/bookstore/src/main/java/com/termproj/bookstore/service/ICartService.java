package com.termproj.bookstore.service;

import com.termproj.bookstore.vo.CartVO;

import java.util.List;

public interface ICartService {

    /**
     * add books to cart
     * @param uid
     * @param bid
     * @param amount
     * @param username
     */
    void addToCart(Integer uid, Integer bid, Integer amount, String username);

    List<CartVO> getVOByUid(Integer uid);
}
