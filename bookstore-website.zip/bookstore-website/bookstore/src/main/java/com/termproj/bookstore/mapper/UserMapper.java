package com.termproj.bookstore.mapper;

// User Interface

import com.termproj.bookstore.entity.User;

import java.util.Date;


public interface UserMapper {
    /**
     * insert user data
     * @param user
     * @return column number in table 'Users'
     */
    Integer insert(User user);

    /**
     * find user data by username
     * @param username
     * @return null if not found, user data if found
     */
    User findByUsername(String username);

    /**
     * change password by uid
     * @param uid
     * @param password
     * @param modifiedUser
     * @param modifiedTime
     * @return affected column No.
     */
    Integer updatePasswordByUid(Integer uid, String password, String modifiedUser, Date modifiedTime);

    /**
     * find user data by uid
     * @param uid
     * @return return obj if found, null if not found
     */
    User findByUid(Integer uid);

    /**
     * update user info
     * @param user
     * @return affected column No.
     */
    Integer updateInfoByUid(User user);


}
