package com.termproj.bookstore.service.impl;


import com.termproj.bookstore.entity.Cart;
import com.termproj.bookstore.entity.Product;
import com.termproj.bookstore.mapper.CartMapper;
import com.termproj.bookstore.mapper.ProductMapper;
import com.termproj.bookstore.service.ICartService;
import com.termproj.bookstore.service.ex.InsertException;
import com.termproj.bookstore.service.ex.UpdateException;
import com.termproj.bookstore.vo.CartVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class CartServiceImpl implements ICartService {
    @Autowired
    private CartMapper cartMapper;
    @Autowired
    private ProductMapper productMapper;

    @Override
    public void addToCart(Integer uid, Integer bid, Integer amount, String username){
        Cart result = cartMapper.findByUidAndBid(uid,bid);
        Date date=new Date();
        if(result == null){
            Cart cart = new Cart();
            cart.setUid(uid);
            cart.setBid(bid);
            cart.setNum(amount);

            Product product= productMapper.findById(bid);
            cart.setPrice(product.getPrice());

            cart.setCreatedTime(date);
            cart.setCreatedUser(username);
            cart.setModifiedTime(date);
            cart.setModifiedUser(username);


            Integer rows=cartMapper.insert(cart);
            if (rows!=1){
                throw new InsertException("Unknown exception during insertion data to cart");
            }
        } else {
            Integer num= result.getNum()+amount;
            Integer rows = cartMapper.updateNumByCid(
                    result.getCid(),
                    num,
                    username,
                    date
            );
            if(rows!=1){
                throw new UpdateException("Unknown exception during updating data");
            }
        }
    }

    @Override
    public List<CartVO> getVOByUid(Integer uid) {
        return cartMapper.findVOByUid(uid);
    }
}
