package com.termproj.bookstore.mapper;

import com.termproj.bookstore.entity.Cart;
import com.termproj.bookstore.vo.CartVO;

import java.util.Date;
import java.util.List;

public interface CartMapper {
    /**
     * insert cart data
     * @param cart
     * @return affected column
     */
    Integer insert(Cart cart);

    /**
     * update a single book's amount
     * @param cid
     * @param num
     * @param modifiedUser
     * @param modifiedTime
     * @return
     */
    Integer updateNumByCid(Integer cid, Integer num, String modifiedUser, Date modifiedTime);

    /**
     * find data by user id and book id
     * @param uid
     * @param bid
     * @return
     */
    Cart findByUidAndBid(Integer uid, Integer bid);

    List<CartVO> findVOByUid (Integer uid);
}
