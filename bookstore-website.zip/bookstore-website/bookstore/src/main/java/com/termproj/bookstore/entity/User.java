package com.termproj.bookstore.entity;

import java.io.Serializable;
import java.util.Objects;

public class User extends BaseEntity implements Serializable {

    private Integer uid;
    private String username;
    private String password;
    private String salt;
    private String phone;
    private String email;
    private Integer active;
    private int subscription;
    private String states;
    private String city;
    private String zip;
    private String street1;
    private String street2;
    private String card;
    private String expire;
    private String cvv;
    private String cardType;
    private String nameOnCard;
    private String verification_code;

    public User() {

    }

    @Override
    public String toString() {
        return "User{" +
                "uid=" + uid +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", salt='" + salt + '\'' +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                ", active=" + active +
                ", subscription=" + subscription +
                ", states='" + states + '\'' +
                ", city='" + city + '\'' +
                ", zip='" + zip + '\'' +
                ", street1='" + street1 + '\'' +
                ", street2='" + street2 + '\'' +
                ", card='" + card + '\'' +
                ", expire='" + expire + '\'' +
                ", cvv='" + cvv + '\'' +
                ", cardType='" + cardType + '\'' +
                ", nameOnCard='" + nameOnCard + '\'' +
                ", verification_code='" + verification_code + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        if (!super.equals(o)) return false;
        User user = (User) o;
        return getSubscription() == user.getSubscription() && Objects.equals(getUid(), user.getUid()) && Objects.equals(getUsername(), user.getUsername()) && Objects.equals(getPassword(), user.getPassword()) && Objects.equals(getSalt(), user.getSalt()) && Objects.equals(getPhone(), user.getPhone()) && Objects.equals(getEmail(), user.getEmail()) && Objects.equals(getActive(), user.getActive()) && Objects.equals(getStates(), user.getStates()) && Objects.equals(getCity(), user.getCity()) && Objects.equals(getZip(), user.getZip()) && Objects.equals(getStreet1(), user.getStreet1()) && Objects.equals(getStreet2(), user.getStreet2()) && Objects.equals(getCard(), user.getCard()) && Objects.equals(getExpire(), user.getExpire()) && Objects.equals(getCvv(), user.getCvv()) && Objects.equals(getCardType(), user.getCardType()) && Objects.equals(getNameOnCard(), user.getNameOnCard()) && Objects.equals(getVerification_code(), user.getVerification_code());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getUid(), getUsername(), getPassword(), getSalt(), getPhone(), getEmail(), getActive(), getSubscription(), getStates(), getCity(), getZip(), getStreet1(), getStreet2(), getCard(), getExpire(), getCvv(), getCardType(), getNameOnCard(), getVerification_code());
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        this.salt = salt;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getActive() {
        return active;
    }

    public void setActive(Integer active) {
        this.active = active;
    }

    public int getSubscription() {
        return subscription;
    }

    public void setSubscription(int subscription) {
        this.subscription = subscription;
    }

    public String getStates() {
        return states;
    }

    public void setStates(String states) {
        this.states = states;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getStreet1() {
        return street1;
    }

    public void setStreet1(String street1) {
        this.street1 = street1;
    }

    public String getStreet2() {
        return street2;
    }

    public void setStreet2(String street2) {
        this.street2 = street2;
    }

    public String getCard() {
        return card;
    }

    public void setCard(String card) {
        this.card = card;
    }

    public String getExpire() {
        return expire;
    }

    public void setExpire(String expire) {
        this.expire = expire;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getNameOnCard() {
        return nameOnCard;
    }

    public void setNameOnCard(String nameOnCard) {
        this.nameOnCard = nameOnCard;
    }

    public String getVerification_code() {
        return verification_code;
    }

    public void setVerification_code(String verification_code) {
        this.verification_code = verification_code;
    }

    public User(Integer uid, String username, String password, String salt, String phone, String email, Integer active, int subscription, String states, String city, String zip, String street1, String street2, String card, String expire, String cvv, String cardType, String nameOnCard, String verification_code) {
        this.uid = uid;
        this.username = username;
        this.password = password;
        this.salt = salt;
        this.phone = phone;
        this.email = email;
        this.active = active;
        this.subscription = subscription;
        this.states = states;
        this.city = city;
        this.zip = zip;
        this.street1 = street1;
        this.street2 = street2;
        this.card = card;
        this.expire = expire;
        this.cvv = cvv;
        this.cardType = cardType;
        this.nameOnCard = nameOnCard;
        this.verification_code = verification_code;
    }
}
