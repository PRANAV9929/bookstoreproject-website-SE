package com.termproj.bookstore.controller;

import com.termproj.bookstore.service.ICartService;
import com.termproj.bookstore.util.JsonResult;
import com.termproj.bookstore.vo.CartVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
@RequestMapping("carts")
public class CartController extends BaseController{
        @Autowired
        private ICartService cartService;

        @RequestMapping("add_to_cart")
        public JsonResult<Void> addToCart(Integer bid,
                                          Integer amount,
                                          HttpSession session){
            cartService.addToCart(
                    getuidFromSession(session),
                    bid,
                    amount,
                    getUsernameFromSession(session)
            );
            return new JsonResult<>(OK);
        }

    @RequestMapping({"","/"})
    public JsonResult<List<CartVO>> getVOByUid(HttpSession session){
            List<CartVO> data=cartService.getVOByUid(getuidFromSession(session));

        return new JsonResult<>(OK,data);
    }

}
