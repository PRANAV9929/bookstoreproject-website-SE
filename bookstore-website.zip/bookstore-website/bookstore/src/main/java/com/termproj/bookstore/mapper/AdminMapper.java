package com.termproj.bookstore.mapper;

import com.termproj.bookstore.entity.Admin;

public interface AdminMapper {

    Admin findByUsername(String username);

    Admin loginVerify(String username, String password);
}
