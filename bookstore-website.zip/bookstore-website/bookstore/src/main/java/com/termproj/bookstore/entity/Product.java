package com.termproj.bookstore.entity;

import java.io.Serializable;
import java.util.Objects;

public class Product extends BaseEntity implements Serializable {

    private Integer id;
    private String category;
    private String title;
    private Integer price;
    private Integer num;
    private String image;
    private Integer status;
    private String author;
    private Integer ISBN;

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", category='" + category + '\'' +
                ", title='" + title + '\'' +
                ", price=" + price +
                ", num=" + num +
                ", image='" + image + '\'' +
                ", status=" + status +
                ", author='" + author + '\'' +
                ", ISBN=" + ISBN +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Product)) return false;
        if (!super.equals(o)) return false;
        Product product = (Product) o;
        return Objects.equals(getId(), product.getId()) && Objects.equals(getCategory(), product.getCategory()) && Objects.equals(getTitle(), product.getTitle()) && Objects.equals(getPrice(), product.getPrice()) && Objects.equals(getNum(), product.getNum()) && Objects.equals(getImage(), product.getImage()) && Objects.equals(getStatus(), product.getStatus()) && Objects.equals(getAuthor(), product.getAuthor()) && Objects.equals(getISBN(), product.getISBN());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getId(), getCategory(), getTitle(), getPrice(), getNum(), getImage(), getStatus(), getAuthor(), getISBN());
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Integer getISBN() {
        return ISBN;
    }

    public void setISBN(Integer ISBN) {
        this.ISBN = ISBN;
    }

    public Product(Integer id, String category, String title, Integer price, Integer num, String image, Integer status, String author, Integer ISBN) {
        this.id = id;
        this.category = category;
        this.title = title;
        this.price = price;
        this.num = num;
        this.image = image;
        this.status = status;
        this.author = author;
        this.ISBN = ISBN;
    }
}
