package com.termproj.bookstore.controller;

import com.termproj.bookstore.entity.Admin;
import com.termproj.bookstore.service.IAdminService;
import com.termproj.bookstore.util.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpSession;

@RestController
@RequestMapping("admin")
public class AdminController extends BaseController{

    @Autowired
    private IAdminService adminService;

    @RequestMapping("login")
    public JsonResult<Admin> login(String username, String password, HttpSession session) {
        Admin data = adminService.login(username, password);

        session.setAttribute("uid", data.getUid());
        session.setAttribute("username", data.getUsername());

        System.out.println(getuidFromSession(session));
        System.out.println(getUsernameFromSession(session));
        return new JsonResult<Admin>(OK,data);
    }

}
