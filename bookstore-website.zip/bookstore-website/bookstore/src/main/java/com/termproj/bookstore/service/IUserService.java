package com.termproj.bookstore.service;

import com.termproj.bookstore.entity.User;

public interface IUserService {

    /**
     * registration
     * @param user
     */
    void reg(User user);

    /**
     * User Login
     * @param username
     * @param password
     * @return User data, null if not exist
     */
    User login(String username, String password);



    void changePassword(Integer uid, String username, String oldPassword, String  newPassword);

    /**
     * get user's info by uid
     * @param uid
     * @return user info
     */
    User getByUid(Integer uid);

    /**
     * update user info
     * @param uid
     * @param username
     * @param user
     */
    void changeInfo(Integer uid, String username, User user);

}
