package com.termproj.bookstore.config;

import com.termproj.bookstore.interceptor.LoginInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class LoginInterceptorConfigurer implements WebMvcConfigurer {
    /**
     *
     * @param registry
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        HandlerInterceptor interceptor = new LoginInterceptor();

        List<String> patterns = new ArrayList<>();
        patterns.add("/static/js/**");
        patterns.add("/img/**");
        patterns.add("/register.html");
        patterns.add("/userlogin.html");
        patterns.add("/index.html");
        patterns.add("/browse.html");
        patterns.add("/authors.html");
        patterns.add("/bestsellers.html");
        patterns.add("/catalogue.html");
        patterns.add("/categories.html");
        patterns.add("/fiction.html");
        patterns.add("/historical.html");
        patterns.add("/neweditions.html");
        patterns.add("/mystery.html");
        patterns.add("/inventory.html");
        patterns.add("/users/reg");
        patterns.add("/users/login");
        patterns.add("/admin.css");
        patterns.add("/bestsellersstyle.css");
        patterns.add("/browsestyle.css");
        patterns.add("/cataloguestyle.css");
        patterns.add("/confirmstyle.css");
        patterns.add("/registerstyle.css");
        patterns.add("/user.css");
        patterns.add("/userstyle.css");
        patterns.add("/products/**");
        patterns.add("/registration-confirmation.html");
        patterns.add("/forgotpassword.html");
        patterns.add("/adminlogin.html");
        patterns.add("/admin.css");
        patterns.add("/admin.html");
        patterns.add("/adminstyle.css");

        //interceptor registration complete
        registry.addInterceptor(interceptor).addPathPatterns("/**").excludePathPatterns(patterns);//all urls in /** are intercepted
    }
}
