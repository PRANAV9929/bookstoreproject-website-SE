package com.termproj.bookstore.service.impl;

import com.termproj.bookstore.entity.Admin;
import com.termproj.bookstore.mapper.AdminMapper;
import com.termproj.bookstore.service.IAdminService;
import com.termproj.bookstore.service.ex.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements IAdminService {
    @Autowired
    private AdminMapper adminMapper;

    @Override
    public Admin login(String username, String password) {
        Admin result = adminMapper.findByUsername(username);
        if(result == null){
            throw new UserNotFoundException("Admin does not exist");
        }
        String oldPassword = result.getPassword();
        if (!password.equals(oldPassword)) {
            throw new UserNotFoundException("Incorrect password");
        }

        Admin admin = new Admin();
        admin.setUid(result.getUid());
        admin.setUsername(result.getUsername());

        return admin;

    }

    @Override
    public Admin verifyLogin(String username, String password) {
        Admin result = adminMapper.loginVerify(username, password);

        Admin admin = new Admin();
        admin.setUid(result.getUid());
        admin.setUsername(result.getUsername());

        return admin;
    }
}
