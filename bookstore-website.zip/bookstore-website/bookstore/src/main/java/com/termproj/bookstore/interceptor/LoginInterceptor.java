package com.termproj.bookstore.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.handler.Handler;

/**
 * declare an interceptor
 * */
public class LoginInterceptor implements HandlerInterceptor {
    /**
     * if there exist uid in session, pass, if there's not, re-direct
     * @param request
     * @param response
     * @param handler
     * @return if return true, pass, if return false, stop
     * @throws Exception
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        Object obj = request.getSession().getAttribute("uid");
        if(obj == null){
            response.sendRedirect("/userlogin.html");
            //end
            return false;
        }
        //pass
        return true;
    }

}
