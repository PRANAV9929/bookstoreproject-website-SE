package com.termproj.bookstore.controller;

import com.termproj.bookstore.service.ex.*;
import com.termproj.bookstore.util.JsonResult;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpSession;

public class BaseController {
    //success code
    public static final int OK = 200;

    @ExceptionHandler(ServiceException.class)
    public JsonResult<Void> handleException(Throwable e){
        JsonResult<Void> result = new JsonResult<>(e);
        if (e instanceof UsernameDuplicatedException){
            result.setState(4000);
            result.setMessage("Username already exists");
        } else if (e instanceof ProductNotFoundException){
            result.setState(4001);
            result.setMessage("Product Not Found Exception");
        } else if (e instanceof UserNotFoundException){
            result.setState(5001);
            result.setMessage("User Not Found Exception");
        } else if (e instanceof PasswordNotMatchException){
            result.setState(5002);
            result.setMessage("Password Not Match Exception");
        } else if (e instanceof InsertException){
            result.setState(5000);
            result.setMessage("Unknown exception");
        } else if (e instanceof UpdateException){
            result.setState(5003);
            result.setMessage("Unknown exception during updating data");
        }
        return result;
    }

    /**
     * get uid from session
     * @param session
     * @return uid
     */
    protected final Integer getuidFromSession(HttpSession session){
        return Integer.valueOf(session.getAttribute("uid").toString());
    }

    /**
     * get Username from session
     * @param session
     * @return username
     */
    protected final String getUsernameFromSession(
            HttpSession session
    ){
        return session.getAttribute("username").toString();
    }


}
