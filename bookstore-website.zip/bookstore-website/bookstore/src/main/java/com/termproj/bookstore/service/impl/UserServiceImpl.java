package com.termproj.bookstore.service.impl;

import com.termproj.bookstore.entity.User;
import com.termproj.bookstore.mapper.UserMapper;
import com.termproj.bookstore.service.IUserService;
import com.termproj.bookstore.service.ex.*;
import net.bytebuddy.utility.RandomString;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;

import java.util.Date;
import java.util.UUID;

@Service
public class UserServiceImpl implements IUserService {
    @Autowired
    private UserMapper userMapper;

    @Override
    public void reg(User user) {
        String username = user.getUsername();
        //check for duplicate username first
        User result = userMapper.findByUsername(username);

        String oldPassword = user.getPassword();

        String salt = UUID.randomUUID().toString().toUpperCase();

        String md5Password = getMD5Password(oldPassword, salt);

        Integer active = 0;

        String randomCode = RandomString.make(5);

        user.setVerification_code(randomCode);

        user.setPassword(md5Password);

        user.setSubscription(1);



        if (result != null){
            throw new UsernameDuplicatedException("Username already exist");
        }
        //set default
        user.setCreatedUser(user.getUsername());
        user.setModifiedUser(user.getUsername());
        Date date = new Date();
        user.setCreatedTime(date);
        user.setModifiedTime(date);
        user.setActive(active);
        user.setSalt(salt);

        Integer rows = userMapper.insert(user);
        if (rows != 1){
            throw new InsertException("Unknown exception,probably server is down");
        }
    }

    @Override
    public User login(String username, String password) {
        User result = userMapper.findByUsername(username);
        if(result == null){
            throw new UserNotFoundException("User does not exist");
        }
        String oldPassword = result.getPassword();
        String salt = result.getSalt();
        String newMd5Password = getMD5Password(password,salt);
        if (!newMd5Password.equals(oldPassword)){
            throw new PasswordNotMatchException("incorrect password");
        }

        User user = new User();
        user.setUid(result.getUid());
        user.setUsername(result.getUsername());


        return user;
    }




    /**
     * md5 encoding
     */

    private String getMD5Password(String password, String salt){
        //three times
        for (int i = 0; i < 3; i++) {
            password = DigestUtils.md5DigestAsHex((salt+password+salt).getBytes()).toUpperCase();
        }
        return password;
    }

    @Override
    public void changePassword(Integer uid, String username, String oldPassword, String newPassword) {
        User result = userMapper.findByUid(uid);
        if (result == null){
            throw new UserNotFoundException("User does not exist");
        }
        //compare old password with password in database
        String oldMd5Password = getMD5Password(oldPassword, result.getSalt());
        if(!result.getPassword().equals(oldMd5Password)){
            throw new PasswordNotMatchException("Incorrect  password");
        }
        // update new password
        String newMd5Password = getMD5Password(newPassword, result.getSalt());
        Integer rows = userMapper.updatePasswordByUid(uid, newMd5Password,username, new Date());
        if(rows != 1){
            throw new UpdateException("Unknown exception during updating data");
        }
    }

    @Override
    public User getByUid(Integer uid) {
        User result = userMapper.findByUid(uid);
        if(result==null){
            throw new UserNotFoundException("User does not exists");
        }
        User user = new User();
        user.setUsername(result.getUsername());
        user.setPhone(result.getPhone());
        user.setEmail(result.getEmail());

        user.setStates(result.getStates());
        user.setCity(result.getCity());
        user.setStreet1(result.getStreet1());
        user.setStreet2(result.getStreet2());
        user.setZip(result.getZip());

        user.setCard(result.getCard());
        user.setExpire(result.getExpire());
        user.setCvv(result.getCvv());
        user.setCardType((result.getCardType()));
        user.setNameOnCard(result.getNameOnCard());

        user.setSubscription(result.getSubscription());
        return user;
    }

    @Override
    public void changeInfo(Integer uid, String username, User user) {
        User result = userMapper.findByUid(uid);
        if (result==null)
        {
            throw new UserNotFoundException("User does not exist");
        }
        user.setUid(uid);
        user.setUsername(username);
        user.setModifiedUser(username);
        user.setModifiedTime(new Date());

        Integer rows = userMapper.updateInfoByUid(user);
        if(rows !=1){
            throw new UpdateException("unknown exception during info updating");
        }
    }




}
