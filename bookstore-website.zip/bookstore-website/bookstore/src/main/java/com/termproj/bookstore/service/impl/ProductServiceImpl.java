package com.termproj.bookstore.service.impl;

import com.termproj.bookstore.entity.Product;
import com.termproj.bookstore.mapper.ProductMapper;
import com.termproj.bookstore.service.IProductService;
import com.termproj.bookstore.service.ex.ProductNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements IProductService {

    @Autowired
    private ProductMapper productMapper;

    @Override
    public List<Product> findList() {
        List<Product> list=productMapper.findList();
        for(Product product : list){
            product.setCreatedTime(null);
            product.setCreatedUser(null);
            product.setModifiedTime(null);
            product.setModifiedUser(null);

        }
        return list;
    }

    @Override
    public Product findById(Integer id) {

        Product product = productMapper.findById(id);

        if (product == null) {

            throw new ProductNotFoundException("book data does not exist");
        }


        product.setCreatedUser(null);
        product.setCreatedTime(null);
        product.setModifiedUser(null);
        product.setModifiedTime(null);

        return product;
    }
}
