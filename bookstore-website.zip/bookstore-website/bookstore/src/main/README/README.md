DELIVERABLE 6 -Implementation of Sprint 1 User Stories

follow these steps tp execute the code:

step 1: open IDE(we have used intellij), import the zip file.

step 2: import the database files into workbench and run the server


step3: run the zip file application on intellij IDE


step4: open the browser (preferably chrome)and type -'localhost:8080'

